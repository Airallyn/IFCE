package AFD;

import java.util.List;

public class MetodosAf {
	
	public MetodosAf() {
		
	}
	
	
	//verifica se um estado est� no conjunto de estados
	public boolean verificarEstado(String estado, String[] estados) {
		
		for (int i=0; i<estados.length;i++) {
			if(estado.equals(estados[i])) {
				return true;
			}
		}
		return false;
	}
	
	//verifica o alfabeto da string
	public boolean verificarAlfabeto(String string, String[] alfabeto) {
		
		for (int i=0; i<string.length();i++) {
			
			int cont = 0;
			
			for(int j=0;j<alfabeto.length;j++) {

				if(String.valueOf(string.charAt(i)).equals(alfabeto[j])) {
					break;
				}else {
					cont++;
				}
			}
			if(cont == alfabeto.length) {
				return false;
			}
		}
		return true;
	}//fim do metodo
	
	//encontra um no que tem o estado fornecido
	public Node encontrarNo(String est, List<Node> listaTransicao) {
		for (int d=0;d<listaTransicao.size();d++) { //para cada no da lista de transicao
			
			if (listaTransicao.get(d).getEstado().equals(est)) {
				return listaTransicao.get(d);
			}
		}
		return null;
	}//fim do metodo
	
	//metodo que insere n�s na lista de estados
	public void povoarLista(List<Node> listaTransicao, String estadoInicial, String[] estados) {
		
		listaTransicao.add(new Node(estadoInicial)); //primeiro n� da lista tem o estado inicial
		for (int i=0;i<estados.length;i++) {
			
			if(! estados[i].equals(estadoInicial)) {
				listaTransicao.add(new Node(estados[i])); //adciona n�s a lista com os estados passados
			}
		}
	}//fim do metodo

}//fim da classe
