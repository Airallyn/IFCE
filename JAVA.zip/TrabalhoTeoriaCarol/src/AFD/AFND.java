package AFD;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;

public class AFND {
	
	private MetodosAf metodoAF = new MetodosAf(); //inst�ncia a classe com os m�todos em comum para os af�s
	private Node no;
	private String estadoInicial;
	private String[] estadoFinal;
	private String[] alfabeto;
	private String[] estados;
	
	private int lin, col;
	
	private JTable funcaoTransicao;
	
	private List<Node> listaTransicao; //guarda os n�s do afd
	
	public AFND() {
		
	}
	
	public AFND(String estadoInicial, String estadoFinal, String alfabeto, String estados, JTable funcaoTransicao,String lin, String col) {
		
		/*replaceAll(" ","") tira os espa�os em branco da string se houver algum passado pelo usu�rio
		 * split(",") serapa uma string em um vetor de strings: ex "meu, nome, maria" = ["meu", "nome", "maria"] */
		
		this.estadoInicial = estadoInicial.replaceAll(" ","");
		this.estadoFinal = estadoFinal.replaceAll(" ","").split(",");
		this.alfabeto = alfabeto.replaceAll(" ","").split(",");
		this.estados = estados.replaceAll(" ","").split(",");
		this.funcaoTransicao = funcaoTransicao;
		this.lin =  Integer.parseInt(lin.replaceAll(" ",""));
		this.col = Integer.parseInt(col.replaceAll(" ",""));
		listaTransicao = new ArrayList<Node>();
		
		gerarAFND();
	}
	
	//metodo de verifica��o da string fornecida
	public boolean verificarString(String string) {
		
		if (metodoAF.verificarAlfabeto(string, alfabeto)) { //verifica o alfabeto da string inicialmente			
			
			Node noAtual = metodoAF.encontrarNo(estadoInicial, listaTransicao); //pega o n� com o estado inicial

			//uma lista com os estados atuais do aut�mato
			List<Node> nodesAtuais = new ArrayList<Node>();
			List<String> estadosAtuais = new ArrayList<String>();
			
			nodesAtuais.add(noAtual);
			estadosAtuais.add(estadoInicial); //armazena o estado do no atual do afd

			List<Node> aux = new ArrayList<Node>(); //lista auxiliar
			
			List<Node> aux2 = new ArrayList<Node>(); //lista para colocar os n�s alcan�ados pela clausula vazia
			
			
			//essa rotina retorna todos os estados alcan�ados pelo caractere fornecido
			for (int i=0; i < string.length(); i++) {//percorre toda a string a ser verificada
				
				aux2.addAll(nodesAtuais);
				
				//la�o que pega os n�s alcan�ados pelo caractere vazio
				while(!(aux2.isEmpty())) {
					for(int r=0;r<aux2.size();r++) {
					
						if (!(aux2.get(r).pegarEstado("e") == null)) {
							nodesAtuais.addAll(aux2.get(r).pegarEstado("e"));
							aux2.addAll(aux2.get(r).pegarEstado("e"));
							aux2.remove(r);
							for(int f=0;f<nodesAtuais.size();f++) {
								//System.out.println(nodesAtuais.get(f).getEstado());
							}
						}else {
							aux2.remove(r);
						}
					}
				}
				
				aux.addAll(nodesAtuais); //copia os nos de nodesAtuais para aux
				 //limpa a lista nodesAtuais
				nodesAtuais.clear();
				
				System.out.println("Caractere *************************");
				for (int j=0; j<aux.size();j++) { //percorre toda a lista de n�s atuais
					
					System.out.println(aux.get(j).getEstado() + "\t" + string.charAt(i) + "\t");
					
					if(!(aux.get(j).pegarEstado(String.valueOf(string.charAt(i))) == null)){
						nodesAtuais.addAll(aux.get(j).pegarEstado(String.valueOf(string.charAt(i)))); //pega todos os n�s alcan�ados pelo estado atual
						for(int f=0;f<nodesAtuais.size();f++) {
							System.out.println(nodesAtuais.get(f).getEstado());
						}
					}else {
						
					}
					
					//estadoAtual = noAtual.getEstado();
				}
				aux.clear(); //limpa lista aux
			}//fim da rotina
			
			for (int i=0; i<nodesAtuais.size();i++) { //verifica se o �ltimo estado alcan�ado � um dos estados finais
				for(int j=0;j<estadoFinal.length;j++) {
					if(nodesAtuais.get(i).getEstado().equals(estadoFinal[j])) {
						return true;
					}
				}
	
			}
			return false;
		}else {
			return false;
		}
	}//fim do m�todo
	
	private void gerarAFND() {
		
		metodoAF.povoarLista(listaTransicao, estadoInicial, estados); //insere n�s na lista de estado
		
		for (int i=1;i<lin;i++) {
			for (int j=1;j<col;j++){
				
				if (!(funcaoTransicao.getValueAt(i,j) == null)) { //se uma posi��o n�o � vazia
					
					//System.out.println(funcaoTransicao.getValueAt(i,j));
					
					List<Node> no = new ArrayList<Node>();
					String carac = funcaoTransicao.getValueAt(0,j).toString(); //pega o caractere atual da funcao de transicao
					String est = funcaoTransicao.getValueAt(i,0).toString(); //pega estado atual da funcao de transicao
					
					String[] novoEstado = funcaoTransicao.getValueAt(i,j).toString().split(","); //pega o conjunto de novos estados alcan�ados a partir do caractere encontrado e do estado atual
					
					for (int d=0; d<novoEstado.length;d++) {
						no.add(metodoAF.encontrarNo(novoEstado[d], listaTransicao));
						//System.out.println(carac + "\t" + est + " = " + novoEstado[d]);
					}
					
					//System.out.println(carac + "\t" + est);
					
					listaTransicao.get(i-1).inserirTransicao(carac, no); //adciona a nova transicao ao estado atual (caractere, estado)
				}
			}
		}
	}//fim do metodo
}//fim da classe
