package AFD;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.SwingUtilities;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.UIManager;
import java.awt.Font;

public class InterfaceAFD extends JFrame {

	private int numColunas;
	private int numLinhas;
	private JPanel contentPane;
	private JTable table;
	private AFD afd;
	private AFND afnd;
	private int automato;
	private boolean pageInicial = false;
	private Converter converter;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfaceAFD frame = new InterfaceAFD();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
		
	}

	/**
	 * Create the frame.
	 */
	
	public InterfaceAFD() {
		
		UIManager.getDefaults().put("OptionPane.background",new Color(255,100,100));
		UIManager.put ("Panel.background", new Color(255,100,100));
		
		setTitle("AF Eilifhvysla");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 271, 79);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JButton btnNewButton = new JButton("AFD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pageInicial = true;
				inicio(1);
				
			}
		});
		btnNewButton.setBounds(10, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("AFND");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pageInicial = true;
				inicio(0);
			}
		});
		btnNewButton_1.setBounds(156, 11, 89, 23);
		contentPane.add(btnNewButton_1);
	
	}
	
	public void inicio(final int tipo) {
		
		setTitle("Aut\u00F4mato Finito");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		final JTextArea alfabeto = new JTextArea();
		alfabeto.setBounds(23, 357, 257, 36);
		alfabeto.setLineWrap(true);
		contentPane.add(alfabeto);
		
		//barra de rolagem
		JScrollPane scroll = new JScrollPane(alfabeto); 
        scroll.setBounds(23, 357, 257, 36);                     // <-- THIS
        getContentPane().add(scroll);
		alfabeto.setLineWrap(true);
		alfabeto.setWrapStyleWord(true);
		
		JLabel lblNewLabel = new JLabel("Alfabeto");
		lblNewLabel.setBounds(23, 338, 61, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Estado inicial");
		lblNewLabel_1.setBounds(23, 404, 104, 14);
		contentPane.add(lblNewLabel_1);
		
		final JTextArea estadoInicial = new JTextArea();
		estadoInicial.setBounds(23, 424, 257, 36);
		estadoInicial.setLineWrap(true);
		contentPane.add(estadoInicial);
		
		//barra de rolagem
		JScrollPane scroll1 = new JScrollPane(estadoInicial);
        scroll1.setBounds(23, 424, 257, 36);                     // <-- THIS
        getContentPane().add(scroll1);
		estadoInicial.setLineWrap(true);
		estadoInicial.setWrapStyleWord(true);
		
		JLabel lblNewLabel_2 = new JLabel("Estado Final");
		lblNewLabel_2.setBounds(23, 474, 104, 14);
		contentPane.add(lblNewLabel_2);
		
		final JTextArea estadoFinal = new JTextArea();
		estadoFinal.setBounds(23, 494, 257, 36);
		estadoFinal.setLineWrap(true);
		contentPane.add(estadoFinal);
		
		//barra de rolagem
		JScrollPane scroll2 = new JScrollPane(estadoFinal);
        scroll2.setBounds(23, 494, 257, 36);                     // <-- THIS
        getContentPane().add(scroll2);
		estadoFinal.setLineWrap(true);
		estadoFinal.setWrapStyleWord(true);
		
		JLabel lblNewLabel_3 = new JLabel("Estados");
		lblNewLabel_3.setBounds(23, 542, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		final JTextArea conjuntoEstados = new JTextArea();
		conjuntoEstados.setBounds(23, 562, 257, 36);
		conjuntoEstados.setLineWrap(true);
		contentPane.add(conjuntoEstados);
		
		//barra de rolagem
		JScrollPane scroll3 = new JScrollPane(conjuntoEstados);
        scroll3.setBounds(23, 562, 257, 36);                     // <-- THIS
        getContentPane().add(scroll3);
		conjuntoEstados.setLineWrap(true);
		conjuntoEstados.setWrapStyleWord(true);
		
		final JTextArea linhaTable = new JTextArea(); //linha da tabela
		linhaTable.setEditable(true);
		linhaTable.setBounds(23, 25, 29, 22);
		contentPane.add(linhaTable);
		
		final JTextArea colunaTable = new JTextArea();
		colunaTable.setEditable(true);
		colunaTable.setBounds(68, 25, 29, 22);
		contentPane.add(colunaTable);
		
		final JTextArea stringVerificada = new JTextArea();
		stringVerificada.setBounds(377, 25, 349, 36);
		stringVerificada.setLineWrap(true);
		contentPane.add(stringVerificada);
		
		//barra de rolagem
		JScrollPane scroll6 = new JScrollPane(stringVerificada);
        scroll6.setBounds(377, 25, 349, 36);                     // <-- THIS
        getContentPane().add(scroll6);
		stringVerificada.setLineWrap(true);
		stringVerificada.setWrapStyleWord(true);
		
		JLabel lblNewLabel_4 = new JLabel("LIN X COL");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.PLAIN, 11));
		lblNewLabel_4.setBounds(23, 8, 58, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Fun\u00E7\u00E3o de Transi\u00E7\u00E3o");
		lblNewLabel_5.setBounds(23, 52, 141, 14);
		
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("String");
		lblNewLabel_6.setBounds(380, 6, 46, 14);
		contentPane.add(lblNewLabel_6);
		table = new JTable();

		JButton btnNewButton_1 = new JButton("Gerar tabela");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String text = linhaTable.getText(); //captura texto digitado na caixa lin
				String text_2 = colunaTable.getText(); //captura texto digitado na caixa col
				//verifica se os campos da linha e coluina est�o vazios
				if(linhaTable.getText().trim().isEmpty() || colunaTable.getText().trim().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Verifique se os campos LINHA e COLUNA"
							+ " foram preenchidos adequadamente"
							+ " e tente novamente.");
				}else {
					
					numLinhas = Integer.parseInt(text); //converte para inteiro
					numColunas = Integer.parseInt(text_2); //converte para inteiro
					
					table = new JTable(numLinhas, numColunas);
					table.setBounds(23, 72, 300, 250);
					table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
					
			        linhaTable.setEditable(false);
			        colunaTable.setEditable(false);
			        contentPane.add(table);
			      
			        for (int i=0;i<numColunas;i++) {
			            TableColumn column = table.getColumnModel().getColumn(i);
			            column.setMinWidth(25);
			            column.setMaxWidth(25);
			            column.setPreferredWidth(25);
			        }
			        
			        //barra de rolagem
					JScrollPane scroll9 = new JScrollPane(table);
			        scroll9.setBounds(23, 72, 300,250);                     // <-- THIS
			        getContentPane().add(scroll9);

				}
			}
		});
		
		btnNewButton_1.setBounds(209, 26, 114, 23);
		contentPane.add(btnNewButton_1);
		contentPane.add(table);
		
		
		//a��o de verificar uma string no aut�mato
		JButton btnNewButton = new JButton("Verificar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(estadoInicial.getText().trim().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Defina um Aut�mato e tente novamente!!");
				}else {
					if (tipo==1) {
						
						if (afd.verificarString(stringVerificada.getText())) {
							JOptionPane.showMessageDialog(null, "String aceita!!");
						}else {
							JOptionPane.showMessageDialog(null, "String n�o aceita!!");
						}
						
					}else {
						if (afnd.verificarString(stringVerificada.getText())) {
							JOptionPane.showMessageDialog(null, "String aceita!!");
						}else {
							JOptionPane.showMessageDialog(null, "String n�o aceita!!");
						}
					}
				}
			}
		});
		btnNewButton.setBounds(380, 80, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_2;
		if(tipo == 1) {
			btnNewButton_2 = new JButton("Gerar AFD");
		}else {
			btnNewButton_2 = new JButton("Gerar AFND");
		}
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tipo == 1) {
					
					//verifica se os campos foram preenchidos pra gerar o afd
					if(alfabeto.getText().trim().isEmpty() || estadoInicial.getText().trim().isEmpty() || estadoFinal.getText().trim().isEmpty() || conjuntoEstados.getText().trim().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Verifique se todos os campos foram preenchidos adequadamente"
								+ " e tente novamente.");
					}else {
						afd = new AFD(estadoInicial.getText(), estadoFinal.getText(), alfabeto.getText(), conjuntoEstados.getText(), table, linhaTable.getText(), colunaTable.getText());
						JOptionPane.showMessageDialog(null, "AFD gerado com sucesso!!");
					}
					
				}else {
					//verifica se os campos foram preenchidos pra gerar o afd
					if(alfabeto.getText().trim().isEmpty() || estadoInicial.getText().trim().isEmpty() || estadoFinal.getText().trim().isEmpty() || conjuntoEstados.getText().trim().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Verifique se todos os campos foram preenchidos adequadamente"
								+ " e tente novamente.");
					}else {
						afnd = new AFND(estadoInicial.getText(), estadoFinal.getText(), alfabeto.getText(), conjuntoEstados.getText(), table, linhaTable.getText(), colunaTable.getText());
						JOptionPane.showMessageDialog(null, "AFND gerado com sucesso!!");
					}
				}
			}
		});
		btnNewButton_2.setBounds(166, 627, 114, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("TUTORIAL");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tipo == 1) {
					ImageIcon icon = new ImageIcon(InterfaceAFD.class.getResource("tutorialAFD.png"));
	                JOptionPane.showMessageDialog(
	                        null,
	                        "Hello world",
	                        "Hello", JOptionPane.INFORMATION_MESSAGE,
	                        icon);
				}else {
					ImageIcon icon = new ImageIcon(InterfaceAFD.class.getResource("tutorialAFN.png"));
	                JOptionPane.showMessageDialog(
	                        null,
	                        "Hello world",
	                        "Hello", JOptionPane.INFORMATION_MESSAGE,
	                        icon);
				}
			}
		});
		btnNewButton_3.setBounds(670, 627, 104, 23);
		contentPane.add(btnNewButton_3);
		
		if(tipo ==0) {
			JButton btnNewButton_4 = new JButton("Converter AFND/AFD");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					converter = new	Converter(table, estadoInicial.getText(), Integer.parseInt(linhaTable.getText()), Integer.parseInt(colunaTable.getText()), alfabeto.getText());
					//inicio(0);
				}
			});
			btnNewButton_4.setBounds(625, 600, 150, 23);
			contentPane.add(btnNewButton_4);
		}
		
		
		
		JButton btnNewButton_5 = new JButton("Resetar");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				alfabeto.setText("");
				estadoInicial.setText("");
				estadoFinal.setText("");
				conjuntoEstados.setText("");
				//textArea_5.setText("");
				//textArea_4.setText("");
				stringVerificada.setText("");
				//textArea_4.setEditable(true);
		        //textArea_5.setEditable(true);
		        
		        //((DefaultTableModel) table.getModel()).setRowCount(0);
			}
		});
		if(tipo ==0) {
			btnNewButton_5.setBounds(670, 570, 104, 23);
		}else {
			btnNewButton_5.setBounds(670, 600, 104, 23);
		}
		
		contentPane.add(btnNewButton_5);
		
	}
}
