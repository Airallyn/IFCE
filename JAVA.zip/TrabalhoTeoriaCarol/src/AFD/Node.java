package AFD;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//classe n� que implementa cada estado e suas transi��es
public class Node {
	
	private String estado;
	
	//dicion�rio que tem como chave um caractere e como valor um (ou conjunto) de n�s
	private Map<String, List<Node>> transicao = new HashMap<String, List<Node>>();
	
	//construtor para n�s vazios
	public Node() {
		
	}
	
	public Node(String estado) {
		this.estado = estado;
	}
	
	//construtor da classe
	public Node(String estado, Map<String, List<Node>> transicao) {
		
		this.estado = estado;
		this.transicao = transicao;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Map<String, List<Node>> getTransicao() {
		return transicao;
	}

	public void setTransicao(Map<String, List<Node>> transicao) {
		this.transicao = transicao;
	}
	
	//insere novas transicoes no estado atual
	public void inserirTransicao(String caractere, List<Node> estado) {
		transicao.put(caractere, estado);
	}
	
	//retorna o estado alcan�ado pelo caractere fornecido
	public List<Node> pegarEstado(String caractere) {
		try {
			return transicao.get(caractere);
		}catch(NullPointerException e) {
			return null;
		}
		
		
	}

}
