package AFD;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JTable;

public class AFD {
	private MetodosAf metodoAF = new MetodosAf();
	
	private String estadoInicial;
	private String[] estadoFinal;
	private String[] alfabeto;
	private String[] estados;

	private int lin;
	private int col;
	
	private JTable funcaoTransicao;
	private List<Node> listaTransicao; //guarda os n�s do afd
	
	public AFD(String estadoInicial, String estadoFinal, String alfabeto, String estados, JTable funcaoTransicao,String lin, String col) {
		
		/*replaceAll(" ","") tira os espa�os em branco da string se houver algum passado pelo usu�rio
		 * split(",") serapa uma string em um vetor de strings: ex "meu, nome, maria" = ["meu", "nome", "maria"] */
		
		this.estadoInicial = estadoInicial.replaceAll(" ","");
		this.estadoFinal = estadoFinal.replaceAll(" ","").split(",");
		this.alfabeto = alfabeto.replaceAll(" ","").split(",");
		this.estados = estados.replaceAll(" ","").split(",");
		this.funcaoTransicao = funcaoTransicao;
		this.lin =  Integer.parseInt(lin.replaceAll(" ",""));
		this.col = Integer.parseInt(col.replaceAll(" ",""));
		
		listaTransicao = new ArrayList<Node>();
		
		gerarAFD();
	}
		
	//m�todo que gera o AFD com base nos pa�metros passados.
	private void gerarAFD() {
		
		metodoAF.povoarLista(listaTransicao, estadoInicial, estados); //insere n�s na lista de estado
		
		for (int i=1;i<lin;i++) {
			for (int j=1;j<col;j++){
				List<Node> no = new ArrayList<Node>();
				String carac = funcaoTransicao.getValueAt(0,j).toString(); //pega o caractere atual da funcao de transicao
				String est = funcaoTransicao.getValueAt(i,0).toString(); //pega estado atual da funcao de transicao
				String NovoEstado = funcaoTransicao.getValueAt(i,j).toString(); //pega novo estado alcan�ado a partir do caractere encontrado e do estado atual
				no.add(metodoAF.encontrarNo(NovoEstado, listaTransicao));
				
				listaTransicao.get(i-1).inserirTransicao(carac, no); //adciona a nova transicao ao estado atual (caractere, estado)
			}
		}
	}//fim do metodo
	
	//m�todo que verifica a string passada
	public boolean verificarString(String string) {

		if (metodoAF.verificarAlfabeto(string, alfabeto)) { //verifica o alfabeto da string inicialmente
			
			Node noAtual = metodoAF.encontrarNo(estadoInicial, listaTransicao); //pega o n� com o estado inicial
			
			String estadoAtual = estadoInicial; //armazena o estado do no atual do afd
			
			//System.out.println("Minha String = "+string);
			
			for (int i=0; i < string.length(); i++) {//percorre toda a string a ser verificada
				
				noAtual = noAtual.pegarEstado(String.valueOf(string.charAt(i))).get(0); //pega pr�ximo n� estado alcan�ado pelo caractere fornecido e substitui o no atual
				estadoAtual = noAtual.getEstado();
			}
			
			for (int i=0; i<estadoFinal.length;i++) { //verifica se o �ltimo estado alcan�ado � um dos estados finais
				
				if(estadoAtual.equals(estadoFinal[i])) {
					return true;
				}
			}
			
			return false;
		}else {
			return false;
		}
		
	}

}//fim da classe
