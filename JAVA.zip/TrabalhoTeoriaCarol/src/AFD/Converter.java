package AFD;

import javax.swing.JTable;
import java.util.List;
import java.util.ArrayList;

public class Converter {
	
	private JTable table;
	private String estadoInicialAFND;
	private int lin, col;
	private String[] alfabeto;
	
	public Converter(JTable table,String estadoInicialAFND, int lin, int col, String alfabeto) {
		
		this.table = table;
		this.estadoInicialAFND = estadoInicialAFND;
		this.lin = lin;
		this.col = col;
		this.alfabeto = alfabeto.split(",");
		converteAFN();
	}
	
	//metodo que converte o AFND em AFD
	public String[][] converteAFN() {
		
		String[][] afd = new String[lin][col];
		
		//List<List<String>> afd = new ArrayList<List<String>>();
		List<List<String>> estadosAFD = new ArrayList<List<String>>(); //lista que vai armazenar os estados afd criados
		List<String> alfabetoLista = new ArrayList<String>();
		String estadoInicialAFD; //estado inicial do AFD gerado
		
		estadoInicialAFD = estadoInicialAFND; //pega o estado inicial do AFND e atribui ao estado inicial do AFD
		alfabetoLista.add("?");
		arrayToList(alfabetoLista, alfabeto); //passa os valores do alfabeto para aux
		
		//primeira linha cont�m os caracteres
		for (int x=0;x<=alfabeto.length-1;x++) {
			afd[0][x+1] = String.valueOf(alfabeto[x]);
		}//funcionando
		
		estadosAFD.add(todosEpsilons(estadoInicialAFND)); //cria o estado inicial AFD e armazena na lista de estadosAFD
		afd[1][0] = "0"; //estado inicial � a posi��o inicial da lista de estadosAFD
		
		List<String> superEstadoEncontrado = new ArrayList<String>(); //lista que guarda temporariamente os estados encontrados
		//System.out.println(superEstadoEncontrado.get(0));
		
		//este la�o vai iterar sobre a lista de estados e obter todas as transi��es deles
		for(int i=0;i<estadosAFD.size(); i++) {
			
			for (int j=0; j<alfabeto.length-1; j++) { //la�o que itera em cada caractere do alfabeto
				
				for (int d=0; d<estadosAFD.get(i).size(); d++) { //itera em cada estados unit�rio do super estado selecionado
					superEstadoEncontrado.addAll(obterEstados(alfabeto[j], estadosAFD.get(i).get(d))); //guarda um super estado alcan�ado pelo estado, caractere alca�ado
				}
				int marca = 0;
				for(int f=0;f<estadosAFD.size(); f++) {//itera novamente nas listas de estados
					
					if(compararListas(alfabetoLista, estadosAFD.get(f))) { //compara se o super estado aux  � igual aos estados j� encontrados. Se for n�o faz nada
						//pegar o indice do estado em estadosAFD colocar esse indice como estado alcan�ado na tabela de
						//transi��o afd
						afd[i+1][j] = String.valueOf(f);
						marca=1;
						break;
					}
				}
				
				if(marca == 0) { //se o super estado n�o existe
					estadosAFD.add(alfabetoLista);
					afd[i+1][j] = String.valueOf(estadosAFD.size()-1);
				}
				
			}
		}
		printar(afd);
		return afd;
	}//fim do metodo
	
	
	
	//metodo que copia os valores de uma lista em uma string
	private List<String> criarLista(String estado) {
		List<String> aux = new ArrayList<String>();
		aux.add(estado);
		return aux;
	}//fim do metodo
	
	//verifica se as listas tem os mesmo elementos (mesmo em posi��es diferentes)
	private boolean compararListas(List<String> lista1, List<String> lista2) {
		List<String> aux1 = new ArrayList<String>();
		List<String> aux2 = new ArrayList<String>();
		
		aux1.addAll(lista1);
		aux2.addAll(lista2);
		
		aux1.removeAll(aux2); //remove todos os elementos que tem na lista1 que s�o iguais aos elementos na lista2
		
		if (aux1.size() == 0) {//se o tamanho da lista1 resultante for 0..
			return true;
		}else {
			return false;
		}
	}//fim do metodo
	
	
	//m�todo que, a partir de um estado fornecido, verifica se ele tem transi��es epsilon e retorna uma lista 
	//com os estados alcan�ados por epsolon.
	public List<String> procurarEpsilon(String estadoAtual) {
		
		List<String> listaEstados = new ArrayList<String>(); //vaiguardar os estados alca�ados
		
		if(table.getValueAt(0,lin-1).toString().equals("e")){ //se a ultima coluna for uma epsilon
			
			String estadosEpsilon;
			String[] estados; //vari�vel que guarda os estados
			
			//verifica qual a linha do estado atual
			for (int j=1;j<lin;j++) {
				
				if(table.getValueAt(0,j).toString().equals(estadoAtual)) {
					
					if (table.getValueAt(0,j) == null) { //se a posi��o epsilon n�o tem transi��es, ent�o sai do la�o
						break;
						
					}else {
						
						estados = table.getValueAt(j,lin-1).toString().split(","); //pega os estados alcan�ados por epsilon a partir do estado atual e os coloca num array de strings
						listaEstados.add(estadoAtual);
						
						arrayToList(listaEstados, estados);//passa os valores do array estados para o arrayList lista												
					}
				}
			}
		}else {
			
		}
		return listaEstados;
	}//fim do metodo
	
	private void printar(String[][] matriz) {
		int lin = matriz.length;
		int col = matriz[0].length;
		
		for (int i=0 ;i < lin; i++) {
			for(int j=0 ; j < col; j++) {
				System.out.println("[ " + matriz[i][j]+" ]\t");
			}
			System.out.println();
		}
	}
	
	//retorna todos os estados epsilons alcan�ados por um estado fornecido
	private List<String> todosEpsilons(String estado){
		
		List<String> listaEstadosAlcancados = new ArrayList<String>();
		listaEstadosAlcancados.add(estado);
		
		for(int i=0;i<listaEstadosAlcancados.size();i++) {//para cada estado
			listaEstadosAlcancados.addAll(procurarEpsilon(estado));
		}
		
		return listaEstadosAlcancados;
	}//fim do metodo
	
	//passa os valores de array para uma lista
	private void arrayToList(List<String> lista, String[] vetor) {
		for (int i=0;i<vetor.length;i++) {
			lista.add(vetor[i]);
		}
		removerElementosIguais(lista);//elimina itens iguais da lista
	}//fim do metodo
	
	//metodo que tira elementos repetidos de uma list<String
	private void removerElementosIguais(List<String> lista) {
		
		for (int i=0;i<lista.size()-1;i++) {
			for (int j=i+1;j<lista.size();j++) {
				
				if(lista.get(i).equals(lista.get(j))){
					lista.remove(j);
					j--;
				}
			}
		}
	}//fim do metodo
	
	//metodo que a partir de um caractere e estado fornecidos, retorna uma lista com os estados
	//alcan�ados (incluindo os estados epsilons)
	private List<String> obterEstados(String caractere, String estado){
		
		List<String> estados= new ArrayList<String>(); //string que guradar� os estados alc�ados
		String[] estadosArray; //array que guarda os estados tempor�riamente
		String estadosString;
		int linha = 0, coluna = 0;
		
		//verifica qual a linha do estado fornecido
		for (int i=0;i<lin;i++) {
			if(table.getValueAt(i,0).toString().equals(estado)) { //para linha
				linha = i;
				break;
			}
		}
		
		//coluna do caractere
		for (int i=0;i<col;i++) {
			if(table.getValueAt(0,i).toString().equals(caractere)) { //para coluna
				coluna = i;
				break;
			}
		}
		
		estadosArray = table.getValueAt(linha,coluna).toString().split(",");
		arrayToList(estados, estadosArray);
		
		for (int i=0; i<estados.size();i++) {
			estados.addAll(todosEpsilons(table.getValueAt(linha,coluna).toString()));
		}
		
		removerElementosIguais(estados);
		return estados;
	}//fim do metodo

}//fim da classe
